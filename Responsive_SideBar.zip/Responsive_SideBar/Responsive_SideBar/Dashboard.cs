﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Responsive_SideBar
{
	public partial class Dashboard : Form
	{


		bool sidebarExpand;
		bool HomeCollapse;
		private Form currentChildForm;
		public Dashboard()
		{
			InitializeComponent();
		}




		private void timer1_Tick(object sender, EventArgs e)
		{
			if (sidebarExpand)
			{
				Main_Panel.Width -= 10;
				if (Main_Panel.Width == Main_Panel.MinimumSize.Width)
				{
					sidebarExpand = false;
					timer1.Stop();
				}


			}
			else
			{

				Main_Panel.Width += 10;
				if (Main_Panel.Width == Main_Panel.MaximumSize.Width)
				{
					sidebarExpand = true;
					timer1.Stop();
				}
			}
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			if (HomeCollapse)
			{
				Home_Panel.Height -= 10;
				if (Home_Panel.Height == Home_Panel.MinimumSize.Height)
				{
					HomeCollapse = false;
					timer2.Stop();
				}


			}
			else
			{

				Home_Panel.Height += 10;
				if (Home_Panel.Height == Home_Panel.MaximumSize.Height)
				{
					HomeCollapse = true;
					timer2.Stop();
				}
			}
		}

		private void pct_Menu_Click(object sender, EventArgs e)
		{
			timer1.Start();
		}

		private void btn_Home_Click(object sender, EventArgs e)
		{
			timer2.Start();
		}

		private void OpenChildForm(Form childForm)
		{
			try
			{
				if (currentChildForm != null)
				{
					currentChildForm.Close();
				}
				currentChildForm = childForm;

				childForm.TopLevel = false;
				childForm.FormBorderStyle = FormBorderStyle.None;
				childForm.Dock = DockStyle.Fill;
				panel_Home.Controls.Add(childForm);
				panel_Home.Tag = childForm;

				childForm.BringToFront();
				childForm.Show();
			}
			catch (Exception ex)
			{
			}
		}

		private void btn_Create_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}

		private void btn_Security_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}

		private void btn_Operator_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}

		private void btn_Logout_Click(object sender, EventArgs e)
		{

			this.Hide();
			Sign_In f = new Sign_In();
			f.Show();
		}

		private void btn_About_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}

		private void btn_Help_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}

		private void btn_Setting_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Home());
		}
	}
}
