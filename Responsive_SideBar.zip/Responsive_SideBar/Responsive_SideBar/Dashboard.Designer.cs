﻿namespace Responsive_SideBar
{
	partial class Dashboard
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
			this.Main_Panel = new System.Windows.Forms.FlowLayoutPanel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lbl_Menu = new System.Windows.Forms.Label();
			this.pct_Menu = new System.Windows.Forms.PictureBox();
			this.Home_Panel = new System.Windows.Forms.Panel();
			this.panel13 = new System.Windows.Forms.Panel();
			this.btn_Operator = new System.Windows.Forms.Button();
			this.panel12 = new System.Windows.Forms.Panel();
			this.btn_Security = new System.Windows.Forms.Button();
			this.panel9 = new System.Windows.Forms.Panel();
			this.btn_Create = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.btn_Home = new System.Windows.Forms.Button();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Logout = new System.Windows.Forms.Button();
			this.panel4 = new System.Windows.Forms.Panel();
			this.btn_About = new System.Windows.Forms.Button();
			this.panel8 = new System.Windows.Forms.Panel();
			this.btn_Help = new System.Windows.Forms.Button();
			this.panel7 = new System.Windows.Forms.Panel();
			this.btn_Setting = new System.Windows.Forms.Button();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.timer2 = new System.Windows.Forms.Timer(this.components);
			this.panel_Home = new System.Windows.Forms.Panel();
			this.Main_Panel.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pct_Menu)).BeginInit();
			this.Home_Panel.SuspendLayout();
			this.panel13.SuspendLayout();
			this.panel12.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel7.SuspendLayout();
			this.SuspendLayout();
			// 
			// Main_Panel
			// 
			this.Main_Panel.BackColor = System.Drawing.Color.Black;
			this.Main_Panel.Controls.Add(this.panel2);
			this.Main_Panel.Controls.Add(this.Home_Panel);
			this.Main_Panel.Controls.Add(this.panel10);
			this.Main_Panel.Controls.Add(this.panel4);
			this.Main_Panel.Controls.Add(this.panel8);
			this.Main_Panel.Controls.Add(this.panel7);
			this.Main_Panel.Dock = System.Windows.Forms.DockStyle.Left;
			this.Main_Panel.Location = new System.Drawing.Point(0, 0);
			this.Main_Panel.MaximumSize = new System.Drawing.Size(198, 749);
			this.Main_Panel.MinimumSize = new System.Drawing.Size(46, 450);
			this.Main_Panel.Name = "Main_Panel";
			this.Main_Panel.Size = new System.Drawing.Size(194, 749);
			this.Main_Panel.TabIndex = 3;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Black;
			this.panel2.Controls.Add(this.lbl_Menu);
			this.panel2.Controls.Add(this.pct_Menu);
			this.panel2.Location = new System.Drawing.Point(3, 3);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(194, 56);
			this.panel2.TabIndex = 1;
			// 
			// lbl_Menu
			// 
			this.lbl_Menu.AutoSize = true;
			this.lbl_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_Menu.ForeColor = System.Drawing.Color.White;
			this.lbl_Menu.Location = new System.Drawing.Point(45, 12);
			this.lbl_Menu.Name = "lbl_Menu";
			this.lbl_Menu.Size = new System.Drawing.Size(51, 16);
			this.lbl_Menu.TabIndex = 1;
			this.lbl_Menu.Text = "MENU";
			// 
			// pct_Menu
			// 
			this.pct_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pct_Menu.Image = ((System.Drawing.Image)(resources.GetObject("pct_Menu.Image")));
			this.pct_Menu.Location = new System.Drawing.Point(3, 9);
			this.pct_Menu.Name = "pct_Menu";
			this.pct_Menu.Size = new System.Drawing.Size(36, 24);
			this.pct_Menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pct_Menu.TabIndex = 0;
			this.pct_Menu.TabStop = false;
			this.pct_Menu.Click += new System.EventHandler(this.pct_Menu_Click);
			// 
			// Home_Panel
			// 
			this.Home_Panel.BackColor = System.Drawing.Color.Black;
			this.Home_Panel.Controls.Add(this.panel13);
			this.Home_Panel.Controls.Add(this.panel12);
			this.Home_Panel.Controls.Add(this.panel9);
			this.Home_Panel.Controls.Add(this.panel3);
			this.Home_Panel.Location = new System.Drawing.Point(3, 65);
			this.Home_Panel.MaximumSize = new System.Drawing.Size(195, 239);
			this.Home_Panel.MinimumSize = new System.Drawing.Size(195, 60);
			this.Home_Panel.Name = "Home_Panel";
			this.Home_Panel.Size = new System.Drawing.Size(195, 237);
			this.Home_Panel.TabIndex = 7;
			// 
			// panel13
			// 
			this.panel13.Controls.Add(this.btn_Operator);
			this.panel13.Location = new System.Drawing.Point(0, 173);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(191, 58);
			this.panel13.TabIndex = 8;
			// 
			// btn_Operator
			// 
			this.btn_Operator.BackColor = System.Drawing.Color.Transparent;
			this.btn_Operator.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Operator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Operator.ForeColor = System.Drawing.Color.White;
			this.btn_Operator.Image = ((System.Drawing.Image)(resources.GetObject("btn_Operator.Image")));
			this.btn_Operator.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Operator.Location = new System.Drawing.Point(0, 11);
			this.btn_Operator.Name = "btn_Operator";
			this.btn_Operator.Size = new System.Drawing.Size(185, 37);
			this.btn_Operator.TabIndex = 5;
			this.btn_Operator.Text = "                  Operator";
			this.btn_Operator.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Operator.UseVisualStyleBackColor = false;
			this.btn_Operator.Click += new System.EventHandler(this.btn_Operator_Click);
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.btn_Security);
			this.panel12.Location = new System.Drawing.Point(0, 121);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(186, 46);
			this.panel12.TabIndex = 7;
			// 
			// btn_Security
			// 
			this.btn_Security.BackColor = System.Drawing.Color.Transparent;
			this.btn_Security.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Security.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Security.ForeColor = System.Drawing.Color.White;
			this.btn_Security.Image = ((System.Drawing.Image)(resources.GetObject("btn_Security.Image")));
			this.btn_Security.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Security.Location = new System.Drawing.Point(0, 3);
			this.btn_Security.Name = "btn_Security";
			this.btn_Security.Size = new System.Drawing.Size(185, 37);
			this.btn_Security.TabIndex = 5;
			this.btn_Security.Text = "                 Security";
			this.btn_Security.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Security.UseVisualStyleBackColor = false;
			this.btn_Security.Click += new System.EventHandler(this.btn_Security_Click);
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.btn_Create);
			this.panel9.Location = new System.Drawing.Point(0, 67);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(186, 48);
			this.panel9.TabIndex = 6;
			// 
			// btn_Create
			// 
			this.btn_Create.BackColor = System.Drawing.Color.Transparent;
			this.btn_Create.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Create.ForeColor = System.Drawing.Color.White;
			this.btn_Create.Image = ((System.Drawing.Image)(resources.GetObject("btn_Create.Image")));
			this.btn_Create.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Create.Location = new System.Drawing.Point(0, 3);
			this.btn_Create.Name = "btn_Create";
			this.btn_Create.Size = new System.Drawing.Size(185, 37);
			this.btn_Create.TabIndex = 5;
			this.btn_Create.Text = "                 Create user";
			this.btn_Create.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Create.UseVisualStyleBackColor = false;
			this.btn_Create.Click += new System.EventHandler(this.btn_Create_Click);
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Black;
			this.panel3.Controls.Add(this.btn_Home);
			this.panel3.Location = new System.Drawing.Point(-3, 3);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(191, 54);
			this.panel3.TabIndex = 1;
			// 
			// btn_Home
			// 
			this.btn_Home.BackColor = System.Drawing.Color.Transparent;
			this.btn_Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Home.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.btn_Home.Image = ((System.Drawing.Image)(resources.GetObject("btn_Home.Image")));
			this.btn_Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Home.Location = new System.Drawing.Point(3, 3);
			this.btn_Home.Name = "btn_Home";
			this.btn_Home.Size = new System.Drawing.Size(183, 39);
			this.btn_Home.TabIndex = 1;
			this.btn_Home.Text = "                  Home";
			this.btn_Home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Home.UseVisualStyleBackColor = false;
			this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.btn_Logout);
			this.panel10.Location = new System.Drawing.Point(3, 308);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(191, 52);
			this.panel10.TabIndex = 8;
			// 
			// btn_Logout
			// 
			this.btn_Logout.BackColor = System.Drawing.Color.Transparent;
			this.btn_Logout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Logout.ForeColor = System.Drawing.Color.White;
			this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
			this.btn_Logout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Logout.Location = new System.Drawing.Point(0, 3);
			this.btn_Logout.Name = "btn_Logout";
			this.btn_Logout.Size = new System.Drawing.Size(185, 37);
			this.btn_Logout.TabIndex = 1;
			this.btn_Logout.Text = "                   Logout";
			this.btn_Logout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Logout.UseVisualStyleBackColor = false;
			this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.btn_About);
			this.panel4.Location = new System.Drawing.Point(3, 366);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(188, 49);
			this.panel4.TabIndex = 9;
			// 
			// btn_About
			// 
			this.btn_About.BackColor = System.Drawing.Color.Transparent;
			this.btn_About.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_About.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_About.ForeColor = System.Drawing.Color.White;
			this.btn_About.Image = ((System.Drawing.Image)(resources.GetObject("btn_About.Image")));
			this.btn_About.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_About.Location = new System.Drawing.Point(0, 3);
			this.btn_About.Name = "btn_About";
			this.btn_About.Size = new System.Drawing.Size(185, 40);
			this.btn_About.TabIndex = 1;
			this.btn_About.Text = "                   About";
			this.btn_About.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_About.UseVisualStyleBackColor = false;
			this.btn_About.Click += new System.EventHandler(this.btn_About_Click);
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.btn_Help);
			this.panel8.Location = new System.Drawing.Point(3, 421);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(188, 49);
			this.panel8.TabIndex = 10;
			// 
			// btn_Help
			// 
			this.btn_Help.BackColor = System.Drawing.Color.Transparent;
			this.btn_Help.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Help.ForeColor = System.Drawing.Color.White;
			this.btn_Help.Image = ((System.Drawing.Image)(resources.GetObject("btn_Help.Image")));
			this.btn_Help.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Help.Location = new System.Drawing.Point(0, 6);
			this.btn_Help.Name = "btn_Help";
			this.btn_Help.Size = new System.Drawing.Size(185, 37);
			this.btn_Help.TabIndex = 1;
			this.btn_Help.Text = "                    Help";
			this.btn_Help.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Help.UseVisualStyleBackColor = false;
			this.btn_Help.Click += new System.EventHandler(this.btn_Help_Click);
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.btn_Setting);
			this.panel7.Location = new System.Drawing.Point(3, 476);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(188, 49);
			this.panel7.TabIndex = 11;
			// 
			// btn_Setting
			// 
			this.btn_Setting.BackColor = System.Drawing.Color.Transparent;
			this.btn_Setting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btn_Setting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Setting.ForeColor = System.Drawing.Color.White;
			this.btn_Setting.Image = ((System.Drawing.Image)(resources.GetObject("btn_Setting.Image")));
			this.btn_Setting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Setting.Location = new System.Drawing.Point(0, 6);
			this.btn_Setting.Name = "btn_Setting";
			this.btn_Setting.Size = new System.Drawing.Size(185, 37);
			this.btn_Setting.TabIndex = 1;
			this.btn_Setting.Text = "                   Setting";
			this.btn_Setting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Setting.UseVisualStyleBackColor = false;
			this.btn_Setting.Click += new System.EventHandler(this.btn_Setting_Click);
			// 
			// timer1
			// 
			this.timer1.Interval = 10;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// timer2
			// 
			this.timer2.Interval = 10;
			this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
			// 
			// panel_Home
			// 
			this.panel_Home.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.panel_Home.BackColor = System.Drawing.Color.Ivory;
			this.panel_Home.Location = new System.Drawing.Point(200, 3);
			this.panel_Home.Name = "panel_Home";
			this.panel_Home.Size = new System.Drawing.Size(601, 746);
			this.panel_Home.TabIndex = 4;
			// 
			// Dashboard
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Ivory;
			this.ClientSize = new System.Drawing.Size(800, 749);
			this.Controls.Add(this.panel_Home);
			this.Controls.Add(this.Main_Panel);
			this.Name = "Dashboard";
			this.Text = "Dashboard";
			this.Main_Panel.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pct_Menu)).EndInit();
			this.Home_Panel.ResumeLayout(false);
			this.panel13.ResumeLayout(false);
			this.panel12.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.FlowLayoutPanel Main_Panel;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label lbl_Menu;
		private System.Windows.Forms.PictureBox pct_Menu;
		private System.Windows.Forms.Panel Home_Panel;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Button btn_Operator;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Button btn_Security;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Button btn_Create;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Button btn_Home;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Button btn_Logout;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Button btn_About;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Button btn_Help;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Button btn_Setting;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Timer timer2;
		private System.Windows.Forms.Panel panel_Home;
	}
}