﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Responsive_SideBar
{
	public partial class Sign_In : Form
	{
		public Sign_In()
		{
			InitializeComponent();
		}

		private void Check_Show_CheckedChanged(object sender, EventArgs e)
		{
			//if (Check_Show.Checked)
			//{
			//	Txt_Pass.UseSystemPasswordChar = false;


			//}
			//else
			//{
			//	Txt_Pass.UseSystemPasswordChar = true;

			//}
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			//if (checkBox1.Checked)
			//{
			//	pass.UseSystemPasswordChar = false;


			//}
			//else
			//{
			//	pass.UseSystemPasswordChar = true;

			//}
		}

		private void Btn_Login_Click(object sender, EventArgs e)
		{
			this.Hide();
			Dashboard f = new Dashboard();
			f.Show();
		}

		private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
		{
			//if (checkBox1.Checked)
			//{
			//	Txt_Pass.UseSystemPasswordChar = false;


			//}
			//else
			//{
			//	Txt_Pass.UseSystemPasswordChar = true;

			//}
		}

		private void kryptonCheckBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (kryptonCheckBox1.Checked)
			{
				Txt_Pass.UseSystemPasswordChar = false;


			}
			else
			{
				Txt_Pass.UseSystemPasswordChar = true;

			}
		}
	}
}
